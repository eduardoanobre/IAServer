package br.com.ia.services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException; // usado na heurística de falha transitória

import br.com.ia.model.ChatCompletionRequest;
import br.com.ia.model.ChatMessage;
import br.com.ia.model.IaRequest;
import br.com.ia.model.IaResponse;
import br.com.ia.services.client.IAIClient;
import br.com.ia.services.client.IaCallResult;
import br.com.ia.services.client.assitants.OpenAiAssistantsClient;
import br.com.ia.services.client.assitants.OpenAiClient;
import br.com.ia.utils.OpenAICustoUtil;
import br.com.shared.model.enums.EnumModeloIA;

@Component
public class IaProcessor {

    private static final String CORRELATION_ID = "correlationId";

    @Bean
    public Function<Message<IaRequest>, Message<IaResponse>> processIa() { // NOSONAR
        return message -> {
            IaRequest req = message.getPayload();

            // ---- correlationId do header (string) ou header Kafka (byte[]) ou payload ----
            String corr = message.getHeaders().get(CORRELATION_ID, String.class);
            if (corr == null) {
                Object bin = message.getHeaders().get("kafka_correlationId");
                if (bin instanceof byte[] byteArray) {
                    corr = new String(byteArray);
                }
            }
            if (corr == null && req != null) {
                corr = req.getCorrelationId();
            }

            try {
                // ---- validações mínimas ----
                if (req == null) {
                    throw new IllegalArgumentException("IaRequest nulo.");
                }
                EnumModeloIA modeloIA = req.getModeloIA();
                if (modeloIA == null) {
                    throw new IllegalArgumentException("Modelo de IA não informado.");
                }

                // ---- extrai opções ----
                Map<String, Object> opts = req.getOptions() != null ? req.getOptions() : Map.of();
                String apiKey = (String) opts.getOrDefault("api_key", null);
                String assistantId = (String) opts.getOrDefault("assistantId", null);
                Double temperature = opts.containsKey("temperature")
                        ? Double.valueOf(opts.get("temperature").toString()) : null;
                Integer maxTokens = opts.containsKey("max_tokens")
                        ? Integer.valueOf(opts.get("max_tokens").toString()) : null;

                // ---- escolhe client por provider ----
                IAIClient iaClient = switch (modeloIA.getIa()) {
                    case CHATGPT -> new OpenAiClient();
                    case CHATGPT_ASSISTANTS -> new OpenAiAssistantsClient();
                    default -> throw new IllegalArgumentException("IA provider desconhecido: " + modeloIA.getIa());
                };

                // ---- monta request ----
                var chatReq = ChatCompletionRequest.builder()
                        .apiKey(apiKey)
                        .modeloIA(modeloIA)
                        .assistantId(assistantId)
                        .messages(List.of(new ChatMessage("user", req.getPrompt())))
                        .temperature(temperature)
                        .maxTokens(maxTokens)
                        .build();

                // ---- chama provedor ----
                IaCallResult result = iaClient.call(chatReq);

                // ---- monta resposta ----
                HttpHeaders headers = result.getHeaders();
                BigDecimal custo = OpenAICustoUtil.calcularCustoPorHeaders(headers);
                String modelo = result.getModelo();
                int tokensPrompt = Integer.parseInt(headers.getFirst("openai-usage-tokens-prompt"));
                int tokensResposta = Integer.parseInt(headers.getFirst("openai-usage-tokens-completion"));

                IaResponse iaResponse = new IaResponse(
                        corr,
                        result.getResposta(),
                        custo,
                        modelo,
                        tokensPrompt,
                        tokensResposta
                );

                return MessageBuilder
                        .withPayload(iaResponse)
                        .copyHeaders(message.getHeaders())     // mantém key/correlationId/etc.
                        .setHeaderIfAbsent(CORRELATION_ID, corr)
                        .build();

            } catch (Exception e) {
                // === Política de retry/DLT ===
                // Se for falha transitória -> relança para o binder aplicar retry/DLT.
                if (isTransient(e)) {
                    throw new IllegalStateException("Falha transitória ao chamar/processar IA", e);
                }

                // Caso contrário, falha permanente -> retorna payload de erro (sem retry).
                IaResponse erro = new IaResponse(
                        corr,
                        "Erro ao processar IA: " + e.getMessage(),
                        BigDecimal.ZERO,
                        "erro",
                        0,
                        0
                );

                return MessageBuilder
                        .withPayload(erro)
                        .copyHeaders(message.getHeaders())
                        .setHeaderIfAbsent(CORRELATION_ID, corr)
                        .build();
            }
        };
    }

    /**
     * Heurística simples para distinguir falhas transitórias (reprocessar) de falhas permanentes.
     * Ajuste conforme seu cliente/provedor real.
     */
    private boolean isTransient(Throwable t) { // NOSONAR
        // Percorre a cadeia de causas
        Throwable e = t;
        while (e != null) {
            // Rede/IO/timeout comuns
            if (e instanceof java.io.IOException) return true;
            if (e instanceof java.net.ConnectException) return true;
            if (e instanceof java.net.SocketTimeoutException) return true;
            if (e instanceof java.util.concurrent.TimeoutException) return true;

            // Erros HTTP do Spring (ex.: RestTemplate) -> 429/5xx são transitórios
            if (e instanceof HttpStatusCodeException httpEx) {
                int code = httpEx.getStatusCode().value();
                if (code == 429 || (code >= 500 && code < 600)) return true;
            }

            // Heurística textual (fallback) — útil quando o tipo não está disponível
            String msg = e.getMessage();
            if (msg != null) {
                String m = msg.toLowerCase();
                if (m.contains("timeout") || m.contains("timed out")
                        || m.contains("temporarily unavailable")
                        || m.contains("rate limit")
                        || m.contains("429")
                        || m.matches(".*\\b5\\d\\d\\b.*")) {
                    return true;
                }
            }

            e = e.getCause();
        }
        return false;
    }
}
